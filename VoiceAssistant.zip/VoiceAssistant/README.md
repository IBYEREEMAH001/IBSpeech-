# Voice Assistant (Kotlin) – continuous voice commands

Say a command, the app does it. Runs as a foreground service so it keeps listening with the screen off.

## Commands (edit the lists in CommandProcessor.kt to add more or change language)
| Say | Does |
|---|---|
| "open WhatsApp" / "launch TikTok" | opens any installed app by its name |
| "call Mom" | finds the contact by name and calls (dials if call permission is missing) |
| "wifi settings", "open bluetooth settings", "settings" | opens that system settings screen |
| "search weather today" | web search |
| "stop listening" | stops the service |

Set `WAKE_WORD = "jarvis"` in CommandProcessor.kt to require "jarvis open youtube" (avoids accidental calls).

## Build and install – step by step

### A) Android Studio (computer)
1. Android Studio > File > Open > select this VoiceAssistant folder. Let Gradle sync.
2. Connect the phone (USB debugging on) and press Run.

### B) Phone only (no computer): build the APK on GitHub
1. Create a free GitHub account, then a new repository (Add a README = off).
2. In the repo choose Add file > Create new file. In the name box type the full path, e.g. `app/src/main/java/com/example/voiceassistant/VoiceService.kt` (typing `/` makes folders). Paste the file content and commit. Repeat for each file, keeping the same paths:
   - settings.gradle.kts, build.gradle.kts, gradle.properties
   - app/build.gradle.kts
   - app/src/main/AndroidManifest.xml
   - app/src/main/res/layout/activity_main.xml
   - app/src/main/java/com/example/voiceassistant/MainActivity.kt, VoiceService.kt, CommandProcessor.kt
   - .github/workflows/build.yml (add this one last)
3. Open the Actions tab, wait for "Build APK" to finish (about 3–5 min), open the run, download the `voice-assistant-apk` artifact (zip), extract it, and install app-debug.apk (allow "install unknown apps" for your browser/Files app).

## First run
1. Open the app and tap **Start listening**. Each tap walks through the next step: microphone, calls, contacts, notifications, then "Display over other apps" (needed so Android lets a background service open apps), then battery optimization (choose Allow).
2. Tap **Start listening** once more. Speak a command.

## Huawei / EMUI tips
- Settings > Battery > App launch > Voice Assistant > turn off automatic, enable all three (auto-launch, secondary launch, run in background). Otherwise EMUI kills the service.
- Lock the app in the recent-apps screen (pull the card down).
- Speech recognition comes from the Google app: keep it installed and updated. For offline use: Google app > Settings > Voice > Offline speech recognition, then add `EXTRA_PREFER_OFFLINE` (commented line in VoiceService.listen()).
- While the assistant listens, other apps that need the microphone (calls, voice notes) may conflict. Say "stop listening" first.

## How it works
- `VoiceService` creates one SpeechRecognizer, and restarts it after every result or error (SpeechRecognizer only hears one phrase per start). Error codes are handled: silence restarts quickly, busy/client errors recreate the recognizer, network errors retry after 3 s.
- `CommandProcessor` normalizes the text, matches verbs, then acts: launcher-app lookup by label, contact lookup in ContactsContract, settings intents, web search.
- Manifest highlights: `RECORD_AUDIO`, `FOREGROUND_SERVICE_MICROPHONE` + `foregroundServiceType="microphone"`, `<queries>` for app listing and the recognizer (Android 11+), `READ_CONTACTS`, `CALL_PHONE`, `SYSTEM_ALERT_WINDOW`.

## Known limits
- Recognizer may beep between phrases on some phones.
- Continuous listening uses battery and (online mode) data.
- Verbs are English by default; edit the lists for other languages.
