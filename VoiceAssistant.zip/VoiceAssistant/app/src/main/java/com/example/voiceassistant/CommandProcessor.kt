package com.example.voiceassistant

import android.Manifest
import android.app.SearchManager
import android.content.Context
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.provider.ContactsContract
import android.provider.Settings

/**
 * Turns a spoken phrase into an action.
 * handle() returns a feedback message if the phrase was a command, or null if it was ignored.
 *
 * To use another language, edit the verb lists and settingsMap keys below.
 */
class CommandProcessor(private val context: Context) {

    companion object {
        /** Leave empty to accept every phrase. Set e.g. "jarvis" to require "jarvis open youtube". */
        const val WAKE_WORD = ""

        private val OPEN_VERBS = listOf("open", "launch", "start", "go to")
        private val CALL_VERBS = listOf("call", "phone", "dial")
        private val SEARCH_VERBS = listOf("search for", "search", "google", "look up")
    }

    /** Keyword spoken -> system settings screen. First match wins, so keep specific ones first. */
    private val settingsMap = linkedMapOf(
        "wifi" to Settings.ACTION_WIFI_SETTINGS,
        "bluetooth" to Settings.ACTION_BLUETOOTH_SETTINGS,
        "display" to Settings.ACTION_DISPLAY_SETTINGS,
        "brightness" to Settings.ACTION_DISPLAY_SETTINGS,
        "sound" to Settings.ACTION_SOUND_SETTINGS,
        "volume" to Settings.ACTION_SOUND_SETTINGS,
        "battery" to Settings.ACTION_BATTERY_SAVER_SETTINGS,
        "location" to Settings.ACTION_LOCATION_SOURCE_SETTINGS,
        "airplane" to Settings.ACTION_AIRPLANE_MODE_SETTINGS,
        "storage" to Settings.ACTION_INTERNAL_STORAGE_SETTINGS,
        "apps" to Settings.ACTION_APPLICATION_SETTINGS,
        "nfc" to Settings.ACTION_NFC_SETTINGS,
        "date" to Settings.ACTION_DATE_SETTINGS,
        "language" to Settings.ACTION_LOCALE_SETTINGS,
        "accessibility" to Settings.ACTION_ACCESSIBILITY_SETTINGS
    )

    fun handle(raw: String): String? {
        var text = raw.lowercase()
            .replace("-", "")
            .replace(Regex("[^\\p{L}\\p{N}\\s]"), "")
            .trim()

        if (WAKE_WORD.isNotBlank()) {
            val i = text.indexOf(WAKE_WORD)
            if (i < 0) return null
            text = text.substring(i + WAKE_WORD.length).trim()
        }

        OPEN_VERBS.firstOrNull { text.startsWith("$it ") }?.let {
            val target = text.removePrefix("$it ").trim()
            return if (target.contains("setting")) openSettings(target) else openApp(target)
        }
        CALL_VERBS.firstOrNull { text.startsWith("$it ") }?.let {
            return callContact(text.removePrefix("$it ").trim())
        }
        SEARCH_VERBS.firstOrNull { text.startsWith("$it ") }?.let {
            return webSearch(text.removePrefix("$it ").trim())
        }
        if (text.endsWith("settings") || text == "settings") return openSettings(text)
        return null
    }

    // ---- Settings -------------------------------------------------------------------------

    private fun openSettings(text: String): String {
        val entry = settingsMap.entries.firstOrNull { text.contains(it.key) }
        val ok = launch(Intent(entry?.value ?: Settings.ACTION_SETTINGS))
        val name = entry?.key ?: "main"
        return if (ok) "Opening $name settings" else "Couldn't open $name settings"
    }

    // ---- Apps -----------------------------------------------------------------------------

    private fun squash(s: String) = s.lowercase().replace(Regex("[^\\p{L}\\p{N}]"), "")

    private fun openApp(target: String): String {
        if (target.isBlank()) return "Which app?"
        val pm = context.packageManager
        val launcher = Intent(Intent.ACTION_MAIN).addCategory(Intent.CATEGORY_LAUNCHER)
        val apps = pm.queryIntentActivities(launcher, 0).map {
            squash(it.loadLabel(pm).toString()) to it.activityInfo.packageName
        }
        val key = squash(target)
        val match = apps.firstOrNull { it.first == key }
            ?: apps.firstOrNull { it.first.contains(key) }
            ?: apps.firstOrNull { it.first.length >= 3 && key.contains(it.first) }
            ?: return "No app called \"$target\""

        val intent = pm.getLaunchIntentForPackage(match.second) ?: return "Can't launch \"$target\""
        return if (launch(intent)) "Opening $target" else "Couldn't open $target"
    }

    // ---- Calls ----------------------------------------------------------------------------

    private fun callContact(name: String): String {
        if (name.isBlank()) return "Who should I call?"
        if (context.checkSelfPermission(Manifest.permission.READ_CONTACTS) != PackageManager.PERMISSION_GRANTED) {
            return "Contacts permission missing"
        }
        val key = squash(name)
        val contacts = mutableListOf<Pair<String, String>>()
        context.contentResolver.query(
            ContactsContract.CommonDataKinds.Phone.CONTENT_URI,
            arrayOf(
                ContactsContract.CommonDataKinds.Phone.DISPLAY_NAME,
                ContactsContract.CommonDataKinds.Phone.NUMBER
            ),
            null, null, null
        )?.use { c ->
            while (c.moveToNext()) contacts.add(c.getString(0).orEmpty() to c.getString(1).orEmpty())
        }
        val match = contacts.firstOrNull { squash(it.first) == key }
            ?: contacts.firstOrNull { squash(it.first).contains(key) }
            ?: return "No contact named \"$name\""

        val uri = Uri.fromParts("tel", match.second, null)
        val canCall = context.checkSelfPermission(Manifest.permission.CALL_PHONE) == PackageManager.PERMISSION_GRANTED
        // ACTION_CALL dials immediately; ACTION_DIAL is the safe fallback without permission.
        val ok = launch(Intent(if (canCall) Intent.ACTION_CALL else Intent.ACTION_DIAL, uri))
        return if (ok) "Calling ${match.first}" else "Couldn't call ${match.first}"
    }

    // ---- Search ---------------------------------------------------------------------------

    private fun webSearch(query: String): String {
        if (query.isBlank()) return "Search for what?"
        val ok = launch(Intent(Intent.ACTION_WEB_SEARCH).putExtra(SearchManager.QUERY, query)) ||
            launch(Intent(Intent.ACTION_VIEW, Uri.parse("https://www.google.com/search?q=" + Uri.encode(query))))
        return if (ok) "Searching: $query" else "Couldn't search"
    }

    // ---- Helper ---------------------------------------------------------------------------

    private fun launch(intent: Intent): Boolean = try {
        intent.addFlags(Intent.FLAG_ACTIVITY_NEW_TASK)
        context.startActivity(intent)
        true
    } catch (e: Exception) {
        false
    }
}
