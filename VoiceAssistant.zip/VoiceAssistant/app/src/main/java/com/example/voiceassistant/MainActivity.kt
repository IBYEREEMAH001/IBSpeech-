package com.example.voiceassistant

import android.Manifest
import android.app.Activity
import android.content.Intent
import android.content.pm.PackageManager
import android.net.Uri
import android.os.Build
import android.os.Bundle
import android.os.PowerManager
import android.provider.Settings
import android.widget.Button
import android.widget.TextView
import android.widget.Toast

class MainActivity : Activity() {

    private lateinit var status: TextView
    private lateinit var toggle: Button
    private lateinit var logView: TextView
    private var batteryAsked = false

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        setContentView(R.layout.activity_main)
        status = findViewById(R.id.status)
        toggle = findViewById(R.id.toggle)
        logView = findViewById(R.id.log)

        toggle.setOnClickListener {
            if (VoiceService.isRunning) {
                stopService(Intent(this, VoiceService::class.java))
            } else if (ensureSetup()) {
                startForegroundService(Intent(this, VoiceService::class.java))
            }
            updateUi()
        }
    }

    override fun onResume() {
        super.onResume()
        VoiceService.onLog = { line ->
            logView.append(line + "\n")
            updateUi()
        }
        updateUi()
    }

    override fun onPause() {
        super.onPause()
        VoiceService.onLog = null
    }

    private fun updateUi() {
        val on = VoiceService.isRunning
        status.text = if (on) "Listening…" else "Stopped"
        toggle.text = if (on) "Stop listening" else "Start listening"
    }

    /** Walks through every permission the app needs, one screen at a time. */
    private fun ensureSetup(): Boolean {
        val wanted = mutableListOf(
            Manifest.permission.RECORD_AUDIO,
            Manifest.permission.CALL_PHONE,
            Manifest.permission.READ_CONTACTS
        )
        if (Build.VERSION.SDK_INT >= 33) wanted.add(Manifest.permission.POST_NOTIFICATIONS)

        val missing = wanted.filter { checkSelfPermission(it) != PackageManager.PERMISSION_GRANTED }
        if (missing.isNotEmpty()) {
            requestPermissions(missing.toTypedArray(), 1)
            return false
        }
        if (!Settings.canDrawOverlays(this)) {
            Toast.makeText(this, "Allow “Display over other apps”, then tap Start again", Toast.LENGTH_LONG).show()
            startActivity(Intent(Settings.ACTION_MANAGE_OVERLAY_PERMISSION, Uri.parse("package:$packageName")))
            return false
        }
        val pm = getSystemService(PowerManager::class.java)
        if (!pm.isIgnoringBatteryOptimizations(packageName) && !batteryAsked) {
            batteryAsked = true
            startActivity(Intent(Settings.ACTION_REQUEST_IGNORE_BATTERY_OPTIMIZATIONS, Uri.parse("package:$packageName")))
            return false
        }
        return true
    }

    override fun onRequestPermissionsResult(code: Int, perms: Array<out String>, results: IntArray) {
        super.onRequestPermissionsResult(code, perms, results)
        Toast.makeText(this, "Tap Start again to continue setup", Toast.LENGTH_SHORT).show()
    }
}
