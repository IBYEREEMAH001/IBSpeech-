package com.example.voiceassistant

import android.app.Notification
import android.app.NotificationChannel
import android.app.NotificationManager
import android.app.PendingIntent
import android.app.Service
import android.content.Intent
import android.content.pm.ServiceInfo
import android.os.Build
import android.os.Bundle
import android.os.Handler
import android.os.IBinder
import android.os.Looper
import android.speech.RecognitionListener
import android.speech.RecognizerIntent
import android.speech.SpeechRecognizer
import android.widget.Toast

/**
 * Foreground service that keeps SpeechRecognizer running in a loop.
 * SpeechRecognizer stops after every phrase, so we restart it from onResults/onError.
 */
class VoiceService : Service() {

    companion object {
        const val CHANNEL_ID = "voice_listening"
        @Volatile var isRunning = false
        var onLog: ((String) -> Unit)? = null

        fun log(msg: String) {
            Handler(Looper.getMainLooper()).post { onLog?.invoke(msg) }
        }
    }

    private val handler = Handler(Looper.getMainLooper())
    private var recognizer: SpeechRecognizer? = null
    private lateinit var processor: CommandProcessor
    private var running = false

    private val restartRunnable = Runnable { if (running) listen() }

    override fun onBind(intent: Intent?): IBinder? = null

    override fun onStartCommand(intent: Intent?, flags: Int, startId: Int): Int {
        startInForeground()
        if (!running) {
            if (!SpeechRecognizer.isRecognitionAvailable(this)) {
                log("No speech recognizer found. Install/enable the Google app.")
                stopSelf()
                return START_NOT_STICKY
            }
            processor = CommandProcessor(applicationContext)
            running = true
            isRunning = true
            createRecognizer()
            log("Started")
            listen()
        }
        return START_NOT_STICKY
    }

    private fun startInForeground() {
        val nm = getSystemService(NotificationManager::class.java)
        nm.createNotificationChannel(
            NotificationChannel(CHANNEL_ID, "Voice listening", NotificationManager.IMPORTANCE_LOW)
        )
        val open = PendingIntent.getActivity(
            this, 0, Intent(this, MainActivity::class.java), PendingIntent.FLAG_IMMUTABLE
        )
        val notification = Notification.Builder(this, CHANNEL_ID)
            .setContentTitle("Voice assistant is listening")
            .setContentText("Say “stop listening” or tap to open")
            .setSmallIcon(android.R.drawable.ic_btn_speak_now)
            .setContentIntent(open)
            .setOngoing(true)
            .build()
        if (Build.VERSION.SDK_INT >= 29) {
            startForeground(1, notification, ServiceInfo.FOREGROUND_SERVICE_TYPE_MICROPHONE)
        } else {
            startForeground(1, notification)
        }
    }

    private fun createRecognizer() {
        recognizer?.destroy()
        recognizer = SpeechRecognizer.createSpeechRecognizer(this).apply {
            setRecognitionListener(listener)
        }
    }

    private fun listen() {
        val intent = Intent(RecognizerIntent.ACTION_RECOGNIZE_SPEECH).apply {
            putExtra(RecognizerIntent.EXTRA_LANGUAGE_MODEL, RecognizerIntent.LANGUAGE_MODEL_FREE_FORM)
            putExtra(RecognizerIntent.EXTRA_CALLING_PACKAGE, packageName)
            putExtra(RecognizerIntent.EXTRA_MAX_RESULTS, 3)
            putExtra(RecognizerIntent.EXTRA_PARTIAL_RESULTS, false)
            // putExtra(RecognizerIntent.EXTRA_LANGUAGE, "en-US")   // force a language
            // putExtra(RecognizerIntent.EXTRA_PREFER_OFFLINE, true) // if offline pack installed
        }
        try {
            recognizer?.startListening(intent)
        } catch (e: Exception) {
            log("Recognizer error: ${e.message}")
            scheduleRestart(1000, recreate = true)
        }
    }

    private fun scheduleRestart(delayMs: Long, recreate: Boolean = false) {
        if (!running) return
        handler.removeCallbacks(restartRunnable)
        if (recreate) createRecognizer()
        handler.postDelayed(restartRunnable, delayMs)
    }

    private val listener = object : RecognitionListener {
        override fun onResults(results: Bundle?) {
            val heard = results
                ?.getStringArrayList(SpeechRecognizer.RESULTS_RECOGNITION)
                .orEmpty()
            if (heard.isNotEmpty()) log("Heard: ${heard.first()}")

            for (phrase in heard) {
                if (phrase.lowercase().contains("stop listening")) {
                    stopSelf()
                    return
                }
                val feedback = processor.handle(phrase)
                if (feedback != null) {
                    log("→ $feedback")
                    Toast.makeText(applicationContext, feedback, Toast.LENGTH_SHORT).show()
                    break
                }
            }
            scheduleRestart(300)
        }

        override fun onError(error: Int) {
            when (error) {
                SpeechRecognizer.ERROR_NO_MATCH,
                SpeechRecognizer.ERROR_SPEECH_TIMEOUT -> scheduleRestart(100)

                SpeechRecognizer.ERROR_RECOGNIZER_BUSY,
                SpeechRecognizer.ERROR_CLIENT -> scheduleRestart(1000, recreate = true)

                SpeechRecognizer.ERROR_INSUFFICIENT_PERMISSIONS -> {
                    log("Microphone permission missing")
                    stopSelf()
                }

                SpeechRecognizer.ERROR_NETWORK,
                SpeechRecognizer.ERROR_NETWORK_TIMEOUT,
                SpeechRecognizer.ERROR_SERVER -> {
                    log("Network problem, retrying…")
                    scheduleRestart(3000)
                }

                else -> scheduleRestart(1000, recreate = true)
            }
        }

        override fun onReadyForSpeech(params: Bundle?) {}
        override fun onBeginningOfSpeech() {}
        override fun onRmsChanged(rmsdB: Float) {}
        override fun onBufferReceived(buffer: ByteArray?) {}
        override fun onEndOfSpeech() {}
        override fun onPartialResults(partialResults: Bundle?) {}
        override fun onEvent(eventType: Int, params: Bundle?) {}
    }

    override fun onDestroy() {
        running = false
        isRunning = false
        handler.removeCallbacksAndMessages(null)
        recognizer?.destroy()
        recognizer = null
        log("Stopped")
        super.onDestroy()
    }
}
